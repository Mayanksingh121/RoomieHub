package com.example.room;

public enum FurnishedStatus {
  FULLYFURNISHED,SEMIFURNISHED,UNFURNISHED
}
